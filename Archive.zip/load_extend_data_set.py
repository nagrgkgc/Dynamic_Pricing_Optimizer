import pandas as pd
import numpy as np
import os

# For reproducibility
np.random.seed(42)

df = pd.read_csv("data/train.csv")
df['date'] = pd.to_datetime(df['date'])
df.sort_values(['item', 'date'], inplace=True)
df.head()

item_base_price = (
    df.groupby('item')['item']
      .transform(lambda x: np.random.uniform(10, 200))
)

df['base_price'] = item_base_price

df['price'] = df['base_price'] * (
    1 + np.random.normal(0, 0.10, size=len(df))
)
df['price'] = df['price'].clip(lower=5)
df['price'] = df['price'].round(2)

df['cost_price'] = (
    df['price'] * np.random.uniform(0.60, 0.85, size=len(df))
).round(2)

df['competitor_price'] = (
    df['price'] * (1 + np.random.normal(0, 0.12, len(df)))
).clip(lower=5).round(2)

df['inventory'] = (
    np.random.randint(20, 200, size=len(df))
)

df['stock_days_remaining'] = (
    df['inventory'] / (df['sales'].replace(0, 1))
).round(1)

final_file = "data/store_sales_with_pricing.csv"
df.to_csv(final_file, index=False)
print("Saved enhanced dataset to", final_file)