import pandas as pd

df = pd.read_csv("data/store_sales_with_pricing.csv")
head = df.head()

#print(head)

import seaborn as sns
import matplotlib.pyplot as plt

sns.scatterplot(data=df.sample(5000), x="price", y="sales")
plt.title("Price vs Sales")
#plt.show()

df["revenue"] = df["price"] * df["sales"]
df["profit"] = (df["price"] - df["cost_price"]) * df["sales"]

head = df[["price","sales","revenue","profit"]].head()

#print(head)

import numpy as np
import statsmodels.api as sm

sample = df.sample(50000)

sample["log_sales"] = np.log(sample["sales"] + 1)
sample["log_price"] = np.log(sample["price"])

X = sm.add_constant(sample["log_price"])
y = sample["log_sales"]

model = sm.OLS(y, X).fit()
#print(model.summary())



def dynamic_price(row):
    
    price = row["price"]

    # competitor cheaper
    if row["competitor_price"] < price:
        price -= 0.05 * price

    # high stock -> lower price
    if row["inventory"] > 150:
        price -= 0.03 * price

    # low inventory -> increase price
    if row["inventory"] < 40:
        price += 0.05 * price

    # ensure margin > 10%
    if price < row["cost_price"] * 1.1:
        price = row["cost_price"] * 1.1

    return round(price, 2)

df["dynamic_price"] = df.apply(dynamic_price, axis=1)

df['date'] = pd.to_datetime(df['date'])

df['dayofweek'] = df['date'].dt.dayofweek
df['month'] = df['date'].dt.month


df = df.sort_values(['item','store','date'])

df['lag_1'] = df.groupby(['item','store'])['sales'].shift(1)
df['lag_7'] = df.groupby(['item','store'])['sales'].shift(7)
df['ma_7'] = df.groupby(['item','store'])['sales'].shift(1).rolling(7).mean()

df = df.dropna()

features = [
    "price",
    "competitor_price",
    "inventory",
    "dayofweek",
    "month",
    "lag_1",
    "lag_7",
    "ma_7"
]

target = "sales"

from sklearn.model_selection import train_test_split

X = df[features]
y = df[target]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, shuffle=False
)

from sklearn.ensemble import GradientBoostingRegressor

model = GradientBoostingRegressor()
model.fit(X_train, y_train)

from sklearn.metrics import mean_absolute_error, r2_score

preds = model.predict(X_test)

#print("MAE:", mean_absolute_error(y_test, preds))
#print("R2:", r2_score(y_test, preds))


'''def optimal_price(row):

    # --- 1) historical price range for this item ---
    item_history = df[df["item"] == row["item"]]["price"]
    
    hist_min = item_history.min()
    hist_max = item_history.max()

    # --- 2) business-safe bounds ---
    # at least 10% margin above cost
    min_price = max(hist_min * 0.7, row["cost_price"] * 1.10)

    # not more than 30% above historical max
    max_price = hist_max * 1.30

    # --- 3) search with reasonable increments ---
    best_price = row["price"]
    best_profit = -1

    for p in np.arange(min_price, max_price, 1):

        row_copy = row.copy()
        row_copy["price"] = p

        demand = model.predict(
            pd.DataFrame([row_copy[features]])
        )[0]

        profit = (p - row["cost_price"]) * demand

        if profit > best_profit:
            best_profit = profit
            best_price = p

    return round(best_price, 2)

df["optimized_price"] = df.apply(optimal_price, axis=1)
'''

import joblib

joblib.dump(model, "pricing_model.pkl")
print("Model saved")


joblib.dump(features, "features.pkl")
