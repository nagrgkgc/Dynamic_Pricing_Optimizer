import pandas as pd

# Path to your CSV
CSV_PATH = "data/store_sales_with_pricing.csv"

def build_request_json(item_id, store_id, target_date, price, competitor_price, inventory, cost_price):
    df = pd.read_csv(CSV_PATH)
    df['date'] = pd.to_datetime(df['date'])
    df['sales'] = df['sales'].astype(float)
    
    # sort for lag/rolling
    df = df.sort_values(['item','store','date'])
    
    # lag features
    df['lag_1'] = df.groupby(['item','store'])['sales'].shift(1)
    df['lag_7'] = df.groupby(['item','store'])['sales'].shift(7)
    df['ma_7'] = df.groupby(['item','store'])['sales'].transform(lambda x: x.rolling(7).mean())
    
    # select the most recent historical row for this item/store
    row = df[(df['item']==item_id) & (df['store']==store_id)].sort_values('date').tail(1)
    
    if row.empty:
        raise ValueError(f"No historical data found for item {item_id}, store {store_id}")
    
    row = row.iloc[0]
    
    # fill NaNs in case of insufficient history
    lag_1 = row['lag_1'] if not pd.isna(row['lag_1']) else row['sales']
    lag_7 = row['lag_7'] if not pd.isna(row['lag_7']) else row['sales']
    ma_7  = row['ma_7']  if not pd.isna(row['ma_7'])  else row['sales']
    
    return {
        "item": int(row['item']),
        "store": int(row['store']),
        "price": float(price),
        "competitor_price": float(competitor_price),
        "inventory": int(inventory),
        "dayofweek": int(pd.to_datetime(target_date).dayofweek),
        "month": int(pd.to_datetime(target_date).month),
        "lag_1": float(lag_1),
        "lag_7": float(lag_7),
        "ma_7": float(ma_7),
        "cost_price": float(cost_price)
    }

json_request = build_request_json(
    item_id=7,
    store_id=1,
    target_date="2017-10-31",
    price=76.55,
    competitor_price=66.29,
    inventory=44,
    cost_price=52.21
)

print(json_request)