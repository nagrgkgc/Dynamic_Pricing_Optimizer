import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from main import optimize_price
from item_finder import build_request_json
from main import model, features  # make sure model & features are accessible

st.set_page_config(page_title="Dynamic Pricing Optimizer", layout="wide")
st.title("📈 Dynamic Pricing Optimizer")

st.markdown("""
This tool calculates **optimal price** for products based on:
- Cost price
- Competitor price
- Inventory
- Historical sales trends (lag features auto-calculated)
- Supports single item input or batch CSV upload
""")

# -------------------------------
# Single Item Optimization
# -------------------------------
st.header("🔹 Single Item Optimization")

with st.form(key="single_item_form"):
    item = st.number_input("Item ID", min_value=1, value=7)
    store = st.number_input("Store ID", min_value=1, value=1)
    price = st.number_input("Current Price", 0.0, 1000.0, 100.0)
    competitor_price = st.number_input("Competitor Price", 0.0, 1000.0, 95.0)
    inventory = st.number_input("Inventory", 0, 1000, 100)
    cost_price = st.number_input("Cost Price", 0.0, 1000.0, 70.0)
    target_date = st.date_input("Target Date")
    
    submitted = st.form_submit_button("Calculate Optimal Price")

if submitted:
    try:
        # Build input JSON with lag features
        data = build_request_json(
            item_id=int(item),
            store_id=int(store),
            target_date=str(target_date),
            price=float(price),
            competitor_price=float(competitor_price),
            inventory=int(inventory),
            cost_price=float(cost_price)
        )

        # Calculate optimal price
        result = optimize_price(data)
        st.success("✅ Optimal price calculated!")
        st.json(result)

        # -------------------------------
        # Graphs for single item
        # -------------------------------
        hist_min, hist_max = result['search_range']
        price_range = np.linspace(hist_min, hist_max, 50)
        predicted_demand = []
        predicted_profit = []

        for p in price_range:
            row = data.copy()
            row['price'] = float(p)

            # Inventory adjustment
            if row.get("inventory", 0) > 150:
                row["price"] *= 0.97
            elif row.get("inventory", 0) < 40:
                row["price"] *= 1.05

            # Competitor adjustment
            if "competitor_price" in row and row["competitor_price"] < row["price"]:
                row["price"] *= 0.97

            # Predict demand
            demand = model.predict(pd.DataFrame({feat: [row[feat]] for feat in features}))[0]
            demand *= np.exp(-0.02 * (p - data["price"]))  # price elasticity
            predicted_demand.append(demand)

            # Profit
            profit = (row["price"] - row["cost_price"]) * demand
            predicted_profit.append(profit)

        # Plot Price vs Demand
        st.subheader("📊 Price vs Predicted Demand")
        fig1, ax1 = plt.subplots()
        ax1.plot(price_range, predicted_demand, color="blue", label="Predicted Demand")
        ax1.axvline(result['optimal_price'], color="red", linestyle="--", label="Optimal Price")
        ax1.set_xlabel("Price")
        ax1.set_ylabel("Predicted Demand")
        ax1.legend()
        st.pyplot(fig1)

        # Plot Price vs Profit
        st.subheader("📊 Price vs Profit")
        fig2, ax2 = plt.subplots()
        ax2.plot(price_range, predicted_profit, color="green", label="Profit")
        ax2.axvline(result['optimal_price'], color="red", linestyle="--", label="Optimal Price")
        ax2.set_xlabel("Price")
        ax2.set_ylabel("Profit")
        ax2.legend()
        st.pyplot(fig2)

        # Historical Sales Trend
        st.subheader("📈 Historical Sales Trend")
        df = pd.read_csv("data/store_sales_with_pricing.csv")
        df['date'] = pd.to_datetime(df['date'])
        item_history = df[(df['item'] == int(item)) & (df['store'] == int(store))].sort_values('date')
        fig3, ax3 = plt.subplots()
        ax3.plot(item_history['date'], item_history['sales'], marker='o', color="purple")
        ax3.set_xlabel("Date")
        ax3.set_ylabel("Sales")
        st.pyplot(fig3)

    except ValueError as e:
        st.error(f"Error: {e}")

# -------------------------------
# Batch Optimization
# -------------------------------
st.markdown("---")
st.header("🔹 Batch Optimization via CSV Upload")

st.markdown("""
Upload a CSV file with the following columns:
- `item`, `store`, `price`, `competitor_price`, `inventory`, `cost_price`, `target_date`
""")

uploaded_file = st.file_uploader("Choose CSV", type="csv")

if uploaded_file is not None:
    batch_df = pd.read_csv(uploaded_file)
    results = []

    for idx, row in batch_df.iterrows():
        try:
            data = build_request_json(
                item_id=int(row['item']),
                store_id=int(row['store']),
                target_date=str(row['target_date']),
                price=float(row['price']),
                competitor_price=float(row['competitor_price']),
                inventory=int(row['inventory']),
                cost_price=float(row['cost_price'])
            )
            res = optimize_price(data)
            res['item'] = row['item']
            res['store'] = row['store']
            results.append(res)
        except Exception as e:
            results.append({
                'item': row.get('item'),
                'store': row.get('store'),
                'error': str(e)
            })

    results_df = pd.DataFrame(results)
    st.success("✅ Batch optimization completed!")
    st.dataframe(results_df)

    # Optionally allow download
    csv = results_df.to_csv(index=False)
    st.download_button("Download Results as CSV", data=csv, file_name="batch_optimal_prices.csv", mime="text/csv")
