from fastapi import FastAPI
import pandas as pd
import numpy as np
import joblib

app = FastAPI(title="Dynamic Pricing API")

model = joblib.load("pricing_model.pkl")
features = joblib.load("features.pkl")


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/predict-demand")
def predict_demand(data: dict):

    row = pd.DataFrame([data])

    demand = model.predict(row[features])[0]

    return {
        "predicted_demand": float(demand)
    }


@app.post("/optimize-price")
def optimize_price(data: dict):
    df = pd.read_csv("data/store_sales_with_pricing.csv")

    item_id = data["item"]
    cost_price = data["cost_price"]

    # --- historical range for this item ---
    item_history = df[df["item"] == item_id]["price"]

    hist_min = item_history.min()
    hist_max = item_history.max()

    # ---- handle missing or empty history ----
    if pd.isna(hist_min) or pd.isna(hist_max):
        hist_min = cost_price * 1.05
        hist_max = cost_price * 1.50

    # --- business constraints: tighter bounds for realism ---
    min_price = max(hist_min * 0.9, cost_price * 1.10)   # at least 10% margin
    max_price = min(hist_max * 1.1, cost_price * 3)      # avoid huge jumps

    # ---- ensure valid range ----
    if min_price >= max_price:
        max_price = min_price * 1.25

    best_price = None
    best_profit = -1

    # ---- search prices using linspace to avoid ValueError ----
    for p in np.linspace(min_price, max_price, 50):
        data_copy = data.copy()
        data_copy["price"] = float(p)

        # --- adjust for inventory ---
        if data_copy.get("inventory", 0) > 150:
            data_copy["price"] *= 0.97  # slightly reduce if high stock
        elif data_copy.get("inventory", 0) < 40:
            data_copy["price"] *= 1.05  # slightly increase if low stock

        # --- adjust for competitor price ---
        if "competitor_price" in data_copy and data_copy["competitor_price"] < data_copy["price"]:
            data_copy["price"] *= 0.97  # reduce slightly if competitor cheaper

        # --- predict demand ---
        row = pd.DataFrame([data_copy])
        demand = model.predict(row[features])[0]

        # --- simple price elasticity ---
        demand *= np.exp(-0.02 * (p - data["price"]))  # reduce demand if price rises

        # --- compute profit ---
        profit = (data_copy["price"] - cost_price) * demand

        if profit > best_profit:
            best_profit = profit
            best_price = data_copy["price"]

    return {
        "optimal_price": round(float(best_price), 2),
        "max_profit": round(float(best_profit), 2),
        "search_range": [
            round(float(min_price), 2),
            round(float(max_price), 2)
        ]
    }